//
//  QRViewController.swift
//  Project 329E
//
//  Created by Devan Thakur on 11/17/21.
//

import Foundation
import UIKit

public class QRViewController: UIViewController {
    
}
