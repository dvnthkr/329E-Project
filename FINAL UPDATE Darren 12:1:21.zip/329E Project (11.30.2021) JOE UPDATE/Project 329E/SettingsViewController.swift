//
//  SettingsViewController.swift
//  Project 329E
//
//  Created by Joe Morris on 11/22/21.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth
import CoreData

class SettingsViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var displayName: UILabel!
    
    var email: String = ""
    
    var databaseRef: DatabaseReference!
    var storageRef: StorageReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        databaseRef = Database.database().reference()
        storageRef = Storage.storage().reference()
        
        loadProfileData()
        
        profileImage.layer.cornerRadius = self.profileImage.frame.size.height / 2;
        profileImage.layer.masksToBounds = true
        profileImage.layer.borderWidth = 0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        email = (Auth.auth().currentUser?.email)!
        
        do {
          
        let fetchedResults = retrievePeople(user: email)

        print(fetchedResults)
        
        for person in fetchedResults {
            if let personName = person.value(forKey:"name") {
                if let personEmail = person.value(forKey:"email") {
                    print("Retrieved: \(personName) \(personEmail)")
                    displayName.text = personName as! String
                }
            }
        }
        } catch {
            print("Didn't work")
        }
    }
    
    func retrievePeople(user: String) -> [NSManagedObject] {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"User")
        var fetchedResults:[NSManagedObject]? = nil
        
        let predicate = NSPredicate(format: "email CONTAINS[c] '\(user)'")
        request.predicate = predicate
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        return(fetchedResults)!
        
    }
    
    @IBAction func saveProfileData(_ sender: Any) {
        updateUsersProfile()
    }
    
    @IBAction func cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func getPhotoFromLibrary(_ sender: Any) {
        //create instance of Image picker controller
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
    }

    func updateUsersProfile(){
      //check to see if the user is logged in
        if let userID = Auth.auth().currentUser?.uid{
            let storageItem = storageRef.child("profile").child(userID)
            guard let image = profileImage.image else {return}
            if let newImage = image.pngData(){
                storageItem.putData(newImage, metadata: nil, completion: { (metadata, error) in
                    if error != nil{
                        print(error!)
                        return
                    }
                    storageItem.downloadURL(completion: { (url, error) in
                        if error != nil{
                            print(error!)
                            return
                        }
                        if let profilePhotoURL = url?.absoluteString{
                            
                            let newValuesForProfile =
                            ["photo": profilePhotoURL]
                            
                            //update the firebase database for that user
                            self.databaseRef.child("profile").child(userID).updateChildValues(newValuesForProfile, withCompletionBlock: { (error, ref) in
                                if error != nil{
                                    print(error!)
                                    return
                                }
                                print("Profile Successfully Update")
                            })
                            
                        }
                    })
                })
      
            }
        }
    }
        
    internal func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
    
        var chosenImage = UIImage()
        print(info)
        chosenImage = info[.originalImage] as! UIImage
        profileImage.image = chosenImage
        updateUsersProfile()
        //dismiss
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func loadProfileData(){
        if let userID = Auth.auth().currentUser?.uid{
                databaseRef.child("profile").child(userID).observe(.value, with: { (snapshot) in
                    
                    let values = snapshot.value as? NSDictionary
                    
                    if let profileImageURL = values?["photo"] as? String{
                        print(profileImageURL)
                        let imageURL = NSURL(string: profileImageURL)
                        let imagedData = NSData(contentsOf: imageURL! as URL)!
                        self.profileImage.image = UIImage(data: imagedData as Data)
                    }
                
                })
                
            }
        }
  
}

