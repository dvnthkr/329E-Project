//
//  SetAlarmViewController.swift
//  FinalProject
//
//  Created by Devan Thakur on 10/30/21.
//

import Foundation
import UIKit
import CoreData

class SetAlarmViewController: UIViewController {
    
    var delegate: reloadAlarm!
    var indexPath: IndexPath?
    @IBOutlet weak var saveAlarmButton: UIButton!
    
    var selectedDate = Date()
    @IBOutlet weak var datePicker: UIDatePicker!
    
    //func datePicker;.frame = CGRect(x: 10, y: 50, width self.view.frame.width, height: 200)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        datePicker.datePickerMode = .time
        datePicker.addTarget(self, action: #selector(dateChanged(picker:)), for: .valueChanged)
    }
    
    @objc func dateChanged(picker: UIDatePicker) {
        selectedDate = picker.date
    }

    @IBAction func saveAlarmButtonPressed(_ sender: Any) {
        let fullAlarm = Alarm(context: PersistentController.shared.container.viewContext)
        fullAlarm.time = selectedDate
        fullAlarm.on = true
        fullAlarm.id = UUID().uuidString
        alarmList.append(fullAlarm)
        PersistentController.shared.save()
        delegate.reload()
    }
    
    /*
    @State private var alarmChoice = Date.now
    
    var body: some View {
        DatePicker("Please enter a time", selection: $alarmChoice, displayedComponents: .hourAndMinute)
    }
    */
}

/*
struct ContentView: View {
    
}
 */

/*
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
*/
