//
//  ViewController.swift
//  FinalProj-Darren
//
//  Created by Darren Huang on 11/16/21.
//

import UIKit
import UserNotifications

class Alarm: NSObject {
    var label: String? = nil
    var descript: String? = nil
    var time: Date? = nil
}

//class Observer: NSObject {
//    @objc var objToObserve: Alarm
//    var observation: NSKeyValueObservation?
//    let center = UNUserNotificationCenter.current()
//    let content = UNMutableNotificationContent()
//
//    func notify(dataPassed: Date) {
//        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
//        let request = UNNotificationRequest(identifier: "alarmOff", content: content, trigger: trigger)
//        center.add(request)
//    }
//
//    func setDetails(label: String, descript: String) {
//        content.title = "Alarm"
//        content.subtitle = label
//        content.body = descript
//        content.sound = UNNotificationSound.default
//    }
//
//}

class ViewController: UIViewController {

    var alarmList: Array<Alarm> = []
    var newAlarm = Alarm()
    let center = UNUserNotificationCenter.current()
    var alarmIdentifier: Int = 0

    @IBOutlet weak var alarmsTitle: UINavigationItem!
    @IBOutlet weak var alarmsLabel: UICollectionView!
    @IBOutlet weak var label: UITextField!
    @IBOutlet weak var descrip: UITextField!
    @IBOutlet weak var picker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))

        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    @IBAction func save(_ sender: Any) {
        newAlarm.label = label.text
        newAlarm.descript = descrip.text
        newAlarm.time = picker.date
        
        label.text = ""
        descrip.text = ""
        
        alarmList.append(newAlarm)
        notify(fullAlarm: newAlarm)
    }
    
    func generateNextNumber() -> Int {
        let next = alarmIdentifier + 1
        alarmIdentifier = next
        return next
    }
    
//    @IBAction func print(_ sender: Any) {
//        print(alarmList)
//    }
    
    func notify(fullAlarm: Alarm) {
        let content = UNMutableNotificationContent()
        content.title = "Alarm"
        content.subtitle = fullAlarm.label!
        content.body = fullAlarm.descript!
        content.sound = UNNotificationSound.default
        
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: fullAlarm.time!)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        let request = UNNotificationRequest(identifier: String(generateNextNumber()), content: content, trigger: trigger)
        center.add(request)
    }
}

