//
//  ViewController.swift
//  FinalProj-Darren
//
//  Created by Darren Huang on 11/16/21.
//

import UIKit
import UserNotifications
import AVFoundation

class Alarm: NSObject {
    var label: String? = nil
    var descript: String? = nil
    var time: Date? = nil
}

public var notifClicked = false

//class Observer: NSObject {
//    @objc var objToObserve: Alarm
//    var observation: NSKeyValueObservation?
//    let center = UNUserNotificationCenter.current()
//    let content = UNMutableNotificationContent()
//
//    func notify(dataPassed: Date) {
//        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
//        let request = UNNotificationRequest(identifier: "alarmOff", content: content, trigger: trigger)
//        center.add(request)
//    }
//
//    func setDetails(label: String, descript: String) {
//        content.title = "Alarm"
//        content.subtitle = label
//        content.body = descript
//        content.sound = UNNotificationSound.default
//    }
//
//}

class ViewController: UIViewController {

    var alarmList: Array<Alarm> = []
    var alarmIDList: Array<String> = []
    var newAlarm = Alarm()
    let center = UNUserNotificationCenter.current()
    var alarmIdentifier: Int = 0

    @IBOutlet weak var alarmsTitle: UINavigationItem!
    @IBOutlet weak var alarmsLabel: UICollectionView!
    @IBOutlet weak var label: UITextField!
    @IBOutlet weak var descrip: UITextField!
    @IBOutlet weak var picker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))

        view.addGestureRecognizer(tap)
//        center.removeAllPendingNotificationRequests()
        removeReminderNotifications()
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    @IBAction func save(_ sender: Any) {
        newAlarm.label = label.text
        newAlarm.descript = descrip.text
        newAlarm.time = picker.date
        
        label.text = ""
        descrip.text = ""
        
        alarmList.append(newAlarm)
        DispatchQueue.global().async{
            self.scheduleReminders(fullAlarm: self.newAlarm)
        }
    }
    
    func generateNextNumber() -> String {
        let next = alarmIdentifier + 1
        alarmIdentifier = next
        return String(next)
    }
    
//    @IBAction func print(_ sender: Any) {
//        print(alarmList)
//    }
    
    func scheduleReminders(fullAlarm: Alarm) {
        notifClicked = false
        let calendar = Calendar.current
        var triggerDate = fullAlarm.time!
        for count in 1..<64 {
            if !notifClicked {
                notify(fullAlarm: fullAlarm, snooze: triggerDate)
                sleep(60)
                triggerDate = calendar.date(byAdding: .minute, value: 1, to: triggerDate)!
            } else {
                removeReminderNotifications()
                alarmList = []
                alarmIDList = []
                print(alarmIDList)
                break
            }
        }
    }
    
    func removeReminderNotifications() {
        center.getPendingNotificationRequests() { requests in
            // get all pending notifications with identifiers starting with "reminder"
            let reminderIdentifiers = requests.filter({ $0.identifier.starts(with: "alarm")}).map { $0.identifier }
            self.center.removePendingNotificationRequests(withIdentifiers: reminderIdentifiers)
        }
    }
    
    func notify(fullAlarm: Alarm, snooze: Date) {
        let content = UNMutableNotificationContent()
        content.title = "Alarm"
        content.subtitle = fullAlarm.label!
        content.body = fullAlarm.descript!
//        content.sound = UNNotificationSound.defaultCritical
        
        // can't get this custom sound to work for some reason. also apple limits custom sounds to 30 seconds or less
        content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "329E.HW1-1"))

        let calendar = Calendar.current
        var dateComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: snooze)
        
        let alarmID = "alarm" + generateNextNumber()
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        let request = UNNotificationRequest(identifier: alarmID, content: content, trigger: trigger)
        alarmIDList.append(alarmID)
        print(alarmIDList)
        center.add(request)
    }
    
}

