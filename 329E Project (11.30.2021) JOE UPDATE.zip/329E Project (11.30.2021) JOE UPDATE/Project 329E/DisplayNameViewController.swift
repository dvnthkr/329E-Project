//
//  DisplayNameViewController.swift
//  Project 329E
//
//  Created by Joe Morris on 11/30/21.
//

import UIKit
import FirebaseAuth
import CoreData

class DisplayNameViewController: UIViewController {
    
    @IBOutlet weak var displayName: UITextField!
    var email: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func changeName(_ sender: Any) {
        if displayName.text != "" {
            email = (Auth.auth().currentUser?.email)!
            storePerson(name: displayName.text!, email: email)
        }
    }
    
    func storePerson(name: String, email: String) {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let person = NSEntityDescription.insertNewObject(
            forEntityName: "User", into: context)
        
        // Set the attribute values
        person.setValue(name, forKey: "name")
        person.setValue(email, forKey: "email")
        
        // Commit the changes
        do {
            try context.save()
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
