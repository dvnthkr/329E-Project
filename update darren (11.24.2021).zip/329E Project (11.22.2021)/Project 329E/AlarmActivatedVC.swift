//
//  AlarmActivatedVC.swift
//  QRScanner
//
//  Created by Michael Calizzi on 11/11/21.
//  Copyright © 2021 KM, Abhilash. All rights reserved.
//

import UIKit
import Foundation
import AVFoundation

class AlarmActivatedVC: UIViewController {
    var sound = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        DispatchQueue.global().async {
            self.playAlarm()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        sound = true
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        sound = false
    }
    
    @IBAction func gotoScan(_ sender: Any) {
        performSegue(withIdentifier: "scan", sender: "")
    }
    
    func playAlarm() {
        while true {
            playSoundIfActive()
            sleep(3)
        }
    }
    
    func playSoundIfActive() {
        if sound {
            AudioServicesPlaySystemSound(SystemSoundID(1005))
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
