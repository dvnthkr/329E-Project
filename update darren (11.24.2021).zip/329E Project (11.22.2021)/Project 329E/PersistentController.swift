//
//  PersistentController.swift
//  FinalProject
//
//  Created by Devan Thakur on 11/9/21.
//

import Foundation
import CoreData

class PersistentController {
    
    static let shared = PersistentController()
    
    let container: NSPersistentContainer
    
    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name:"Project_329E")
        if inMemory {
            container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores { _, error in
            print(error?.localizedDescription)
        }
    }
    
    func save() {
        let context = container.viewContext
        if context.hasChanges{
            do {
                try context.save()
            }catch {
                
            }
        }
        
    }
    
}
