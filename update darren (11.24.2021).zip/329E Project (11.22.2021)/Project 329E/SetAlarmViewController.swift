//
//  SetAlarmViewController.swift
//  FinalProject
//
//  Created by Devan Thakur on 10/30/21.
//

import Foundation
import UIKit
import CoreData
import FirebaseAuth

var notifClicked = false

class SetAlarmViewController: UIViewController {
    
    var delegate: reloadAlarm!
    var indexPath: IndexPath?
    @IBOutlet weak var saveAlarmButton: UIButton!
    
    var selectedDate = Date()
    @IBOutlet weak var datePicker: UIDatePicker!
    
    //func datePicker;.frame = CGRect(x: 10, y: 50, width self.view.frame.width, height: 200)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        datePicker.datePickerMode = .time
        datePicker.addTarget(self, action: #selector(dateChanged(picker:)), for: .valueChanged)
        
        // use this to remove all pending notifications in case the snoozes pile up somehow
//        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()

    }
    
    @objc func dateChanged(picker: UIDatePicker) {
        selectedDate = picker.date
    }

    @IBAction func saveAlarmButtonPressed(_ sender: Any) {
        let fullAlarm = Alarm(context: PersistentController.shared.container.viewContext)
        fullAlarm.time = selectedDate
        fullAlarm.on = true
        fullAlarm.id = UUID().uuidString
        fullAlarm.userid = Auth.auth().currentUser?.email
        alarmList.append(fullAlarm)
        SetAlarmViewController.notify(fullAlarm: fullAlarm)
        PersistentController.shared.save()
        delegate.reload()
        navigationController?.popViewController(animated: true)
    }
    
    public static func notify(fullAlarm: Alarm) {
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Alarm"
        content.subtitle = ""
        content.body = ""
        content.sound = UNNotificationSound.default
        
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: fullAlarm.time!)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        let request = UNNotificationRequest(identifier: fullAlarm.id ?? "", content: content, trigger: trigger)
        center.add(request)
        
        // runs schedulereminders asynchronously, even when the app is closed
        DispatchQueue.global().async {
            SetAlarmViewController.scheduleReminders(fullAlarm: fullAlarm)
        }
    }
    
    // schedules snoozes every 60 seconds until notifClicked becomes true, which happens when you scan the correct QR code (currently it's just when you OPEN the QRScannerViewController (for testing purposes), but once we get the QR code thing perfectly functional I can go back and change this to make it turn off the snoozes once the CongratulationsVC appears)
    public static func scheduleReminders(fullAlarm: Alarm) {
        notifClicked = false
        let calendar = Calendar.current
        var triggerDate = fullAlarm.time!
        var id = 1
        for count in 1..<64 {
            if !notifClicked {
                triggerDate = calendar.date(byAdding: .minute, value: 1, to: triggerDate)!
                SetAlarmViewController.snoozeTilClick(snooze: triggerDate, id: id)
                id = id + 1
                sleep(59)
            } else {
                SetAlarmViewController.removeReminderNotifications()
                print("alarm stopped, no more snooze")
                break
            }
        }
    }
    
    // deletes all pending snoozes once QR code is correctly scanned and alarm is turned off
    public static func removeReminderNotifications() {
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests() { requests in
            // get all pending notifications with identifiers starting with "reminder"
            let reminderIdentifiers = requests.filter({ $0.identifier.starts(with: "snooze")}).map { $0.identifier }
            center.removePendingNotificationRequests(withIdentifiers: reminderIdentifiers)
        }
    }
    
    // schedules snoozes every minute until you scan the QR code (currently that's just OPENING the QRScannerViewController--for testing purposes, but once we get the QR code thing perfectly functional I can go back and change this to make it turn off the snoozes once the CongratulationsVC appears)
    public static func snoozeTilClick(snooze: Date, id: Int) {
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Alarm"
        content.subtitle = ""
        content.body = ""
        
        // can't get this custom sound to work for some reason. also apple limits custom sounds to 30 seconds or less
//        content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "329E.HW1-1"))
        content.sound = UNNotificationSound.defaultCriticalSound(withAudioVolume: 1.0)
        
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: snooze)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        let request = UNNotificationRequest(identifier: "snooze" + String(id), content: content, trigger: trigger)
        
        center.add(request)
    }

}

