import Foundation
import UIKit
import AVFoundation

//any vc that uses this view must implement this protocol
protocol QRScannerViewDelegate: class {
    func scanningSucceded(_ str: String?)
}

class QRScannerView: UIView {
    
    //View controller using this view
    weak var delegate: QRScannerViewDelegate?
    
    //Capture session
    var captureSession: AVCaptureSession?
    
    //Initialization
    required init?(coder decoder: NSCoder) {
        super.init(coder: decoder)
        initCapture()
    }
    
    //make it so the view of the layer returns what the camera is currently capturing
    override class var layerClass: AnyClass  {
        return AVCaptureVideoPreviewLayer.self
    }
    override var layer: AVCaptureVideoPreviewLayer {
        return super.layer as! AVCaptureVideoPreviewLayer
    }
}

//implement logic to start and stop the scanner
extension QRScannerView {
    
    //if the setup failed, set the capture session to nil
    func setupFailed() {
        captureSession = nil
    }
    
    var isRunning: Bool {
        return captureSession?.isRunning ?? false
    }
    
    func start() {
       captureSession?.startRunning()
    }
    
    func stop() {
        captureSession?.stopRunning()
    }
    
    
    //setup the capture session
    private func initCapture() {
        clipsToBounds = true
        captureSession = AVCaptureSession()
        
        //get the default camera
        guard let defaultCamera = AVCaptureDevice.default(for: .video) else { return }
        
        //create a new input device
        let inputDevice: AVCaptureDeviceInput
        //try to set the input device to the camera, if failed return an error
        do {
            inputDevice = try AVCaptureDeviceInput(device: defaultCamera)
        } catch let error {
            print(error)
            return
        }
        
        //add the input device to the capture session if it will accept it
        if (captureSession?.canAddInput(inputDevice) ?? false) {
            captureSession?.addInput(inputDevice)
        } else {
            setupFailed()
            return
        }
        
        //create metadata output
        let qrData = AVCaptureMetadataOutput()
        //add output to the capture session, if not run setup failed and return
        if (captureSession?.canAddOutput(qrData) ?? false) {
            captureSession?.addOutput(qrData)
            qrData.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            qrData.metadataObjectTypes = [.qr]
        } else {
            setupFailed()
            return
        }
        
        //display the capture session on the layer
        self.layer.session = captureSession
        self.layer.videoGravity = .resizeAspectFill
        
        //begin the capture session
        captureSession?.startRunning()
    }
}

extension QRScannerView: AVCaptureMetadataOutputObjectsDelegate {
    func metadataOutput(_ output: AVCaptureMetadataOutput,
                        didOutput metadataObjects: [AVMetadataObject],
                        from connection: AVCaptureConnection) {
        //check that the metadata is a qr code
        if let metadataObject = metadataObjects.first {
            //cast as a readable object
            guard let metaData = metadataObject as? AVMetadataMachineReadableCodeObject else { return }
            //get string value and pass to delegate
            guard let str = metaData.stringValue else { return }
            delegate?.scanningSucceded(str)
        }
    }
    
}
