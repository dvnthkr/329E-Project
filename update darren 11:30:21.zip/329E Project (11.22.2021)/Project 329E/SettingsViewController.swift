//
//  SettingsViewController.swift
//  Project 329E
//
//  Created by Joe Morris on 11/22/21.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth

class SettingsViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        
    @IBOutlet weak var profileImage: UIImageView!

    var databaseRef: DatabaseReference!
    var storageRef: StorageReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        databaseRef = Database.database().reference()
        storageRef = Storage.storage().reference()
        
        loadProfileData()
        
        profileImage.layer.cornerRadius = self.profileImage.frame.size.height / 2;
        profileImage.layer.masksToBounds = true
        profileImage.layer.borderWidth = 0
        
    }
    
    @IBAction func saveProfileData(_ sender: Any) {
        updateUsersProfile()
    }
    
    @IBAction func cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func getPhotoFromLibrary(_ sender: Any) {
        //create instance of Image picker controller
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
    }

    func updateUsersProfile(){
      //check to see if the user is logged in
        if let userID = Auth.auth().currentUser?.uid{
            let storageItem = storageRef.child("profile").child(userID)
            guard let image = profileImage.image else {return}
            if let newImage = image.pngData(){
                storageItem.putData(newImage, metadata: nil, completion: { (metadata, error) in
                    if error != nil{
                        print(error!)
                        return
                    }
                    storageItem.downloadURL(completion: { (url, error) in
                        if error != nil{
                            print(error!)
                            return
                        }
                        if let profilePhotoURL = url?.absoluteString{
                            
                            let newValuesForProfile =
                            ["photo": profilePhotoURL]
                            
                            //update the firebase database for that user
                            self.databaseRef.child("profile").child(userID).updateChildValues(newValuesForProfile, withCompletionBlock: { (error, ref) in
                                if error != nil{
                                    print(error!)
                                    return
                                }
                                print("Profile Successfully Update")
                            })
                            
                        }
                    })
                })
      
            }
        }
    }
        
    internal func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
    
        var chosenImage = UIImage()
        print(info)
        chosenImage = info[.originalImage] as! UIImage
        profileImage.image = chosenImage
        updateUsersProfile()
        //dismiss
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func loadProfileData(){
        if let userID = Auth.auth().currentUser?.uid{
                databaseRef.child("profile").child(userID).observe(.value, with: { (snapshot) in
                    
                    let values = snapshot.value as? NSDictionary
                    
                    if let profileImageURL = values?["photo"] as? String{
                        print(profileImageURL)
                        let imageURL = NSURL(string: profileImageURL)
                        let imagedData = NSData(contentsOf: imageURL! as URL)!
                        self.profileImage.image = UIImage(data: imagedData as Data)
                    }
                
                })
                
            }
        }
  
}

