//
//  LoginViewController.swift
//
//  Project: Project-329E
//  EID: JJM5298
//  Course: CS329E
//
//  Created by Joe Morris on 10/22/21.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController {

    @IBOutlet weak var loginSignup: UISegmentedControl!
    
    @IBOutlet weak var userIDLogin: UILabel!
    @IBOutlet weak var passwordLogin: UILabel!
    @IBOutlet weak var userIDTextLogin: UITextField!
    @IBOutlet weak var passwordTextLogin: UITextField!
    @IBOutlet weak var statusLogin: UILabel!
    @IBOutlet weak var signInButton: UIButton!
    
    @IBOutlet weak var userIDSignup: UILabel!
    @IBOutlet weak var passwordSignup: UILabel!
    @IBOutlet weak var passwordConfirmSignup: UILabel!
    @IBOutlet weak var userIDTextSignup: UITextField!
    @IBOutlet weak var passwordTextSignup: UITextField!
    @IBOutlet weak var passwordConfirmTextSignup: UITextField!
    @IBOutlet weak var statusSignup: UILabel!
    @IBOutlet weak var signUpButton: UIButton!
    
    var username: String = ""
    
    
    @IBAction func loginSignupSwitch(_ sender: Any) {
        switch loginSignup.selectedSegmentIndex
        {
        case 0:
            userIDLogin.isHidden = false
            passwordLogin.isHidden = false
            userIDTextLogin.isHidden = false
            passwordTextLogin.isHidden = false
            statusLogin.isHidden = false
            signInButton.isHidden = false
            userIDSignup.isHidden = true
            passwordSignup.isHidden = true
            passwordConfirmSignup.isHidden = true
            userIDTextSignup.isHidden = true
            passwordTextSignup.isHidden = true
            passwordConfirmTextSignup.isHidden = true
            statusSignup.isHidden = true
            signUpButton.isHidden = true
        case 1:
            userIDLogin.isHidden = true
            passwordLogin.isHidden = true
            userIDTextLogin.isHidden = true
            passwordTextLogin.isHidden = true
            statusLogin.isHidden = true
            signInButton.isHidden = true
            userIDSignup.isHidden = false
            passwordSignup.isHidden = false
            passwordConfirmSignup.isHidden = false
            userIDTextSignup.isHidden = false
            passwordTextSignup.isHidden = false
            passwordConfirmTextSignup.isHidden = false
            statusSignup.isHidden = false
            signUpButton.isHidden = false
        default:
            break;
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        
        userIDLogin.isHidden = false
        passwordLogin.isHidden = false
        userIDTextLogin.isHidden = false
        passwordTextLogin.isHidden = false
        statusLogin.isHidden = false
        signInButton.isHidden = false
        userIDSignup.isHidden = true
        passwordSignup.isHidden = true
        passwordConfirmSignup.isHidden = true
        userIDTextSignup.isHidden = true
        passwordTextSignup.isHidden = true
        passwordConfirmTextSignup.isHidden = true
        statusSignup.isHidden = true
        signUpButton.isHidden = true

        // Do any additional setup after loading the view.
    }
    
    @IBAction func loginDidTouch(_ sender: Any) {
      guard let email = userIDTextLogin.text,
            let password = passwordTextLogin.text,
            email.count > 0,
            password.count > 0
      else {
        return
      }
      
        Auth.auth().signIn(withEmail: email, password: password) { [self]
        user, error in
        if let error = error, user == nil {
            self.statusLogin.text = "Sign in failed."
        } else {
            username = email
            self.performSegue(withIdentifier: "loginIdentifier", sender: nil)
        }
      }
    }
    
    @IBAction func signUpDidTouch(_ sender: Any) {
        print("hello")
        
        if passwordTextSignup.text == passwordConfirmTextSignup.text {
            print("hello")
            Auth.auth().createUser(withEmail: self.userIDTextSignup.text!, password: self.passwordTextSignup.text!) { user, error in
                if error == nil {
                    Auth.auth().signIn(withEmail: self.userIDTextSignup.text!,
                                       password: self.passwordTextSignup.text!)
                    self.username = self.userIDTextSignup.text!
                    self.performSegue(withIdentifier: "loginIdentifier", sender: nil)
                } else {
                    self.statusSignup.text = "Check your email and password."
                }
            }
        } else {
            self.statusSignup.text = "Check your email and password."
        }
        
      }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    // code to enable tapping on the background to remove software keyboard
        
    func textFieldShouldReturn(textField:UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

}
