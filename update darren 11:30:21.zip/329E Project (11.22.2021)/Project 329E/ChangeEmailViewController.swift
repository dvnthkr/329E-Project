//
//  ChangeEmailViewController.swift
//  Project 329E
//
//  Created by Joe Morris on 11/15/21.
//

import UIKit
import FirebaseAuth

class ChangeEmailViewController: UIViewController {
    
    @IBOutlet weak var confirmEmail: UITextField!
    @IBOutlet weak var newEmail: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func changeEmail(_ sender: Any) {
        let currentUser = Auth.auth().currentUser
        
        if newEmail.text == confirmEmail.text {
            currentUser?.updateEmail(to: newEmail.text!) { error in
                if let error = error {
                    print(error)
                    self.statusLabel.text = "Please try again"
                } else {
                    print("CHANGED")
                    self.statusLabel.text = "Email Changed"
                }
            }
        } else {
            statusLabel.text = "Please try again"
        }
    }
    
}
