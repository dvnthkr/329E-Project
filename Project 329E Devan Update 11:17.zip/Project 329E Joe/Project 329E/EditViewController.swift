//
//  EditViewController.swift
//  FinalProject
//
//  Created by Devan Thakur on 11/9/21.
//

import Foundation
import UIKit
import CoreData

class EditViewController: UIViewController {
    
    @IBOutlet weak var editTime: UIDatePicker!
    @IBOutlet weak var saveEditedAlarm: UIButton!
    @IBOutlet weak var deleteAlarm: UIButton!
    
    var alarm: Alarm?
    weak var delegate: reloadAlarm?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        deleteAlarm.addTarget(self, action: #selector(didTapDeleteAlarm), for: .touchUpInside)
        saveEditedAlarm.addTarget(self, action: #selector(didTapEditAlarm), for: .touchUpInside)
        
    }
    
    @objc func didTapDeleteAlarm() {
        guard let alarmId = alarm?.id else {
            return
        }
        deleteAlarm(id: alarmId)
        delegate?.reload()
    }
    
    private func deleteAlarm(id: String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let request = Alarm.fetchRequest()
        request.predicate = NSPredicate.init(format: "id==%@", id)
        do {
            let objects = try PersistentController.shared.container.viewContext.fetch(request)
            for object in objects {
                PersistentController.shared.container.viewContext.delete(object)
            }
            PersistentController.shared.save()
            EditViewController.deleteNotify(fullAlarm: alarm!)
            navigationController?.popViewController(animated: true)
        }catch {
            
        }
    }
    
    public static func deleteNotify(fullAlarm: Alarm) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [fullAlarm.id ?? ""])
    }
    
    @objc func didTapEditAlarm() {
        guard let alarmId = alarm?.id else {
            return
        }
        editAlarm(id: alarmId)
        delegate?.reload()
        //navigationController?.popToRootViewController(animated: true)
    }
    
    private func editAlarm(id: String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let request = Alarm.fetchRequest()
        request.predicate = NSPredicate.init(format: "id==%@", id)
        do {
            let objects = try PersistentController.shared.container.viewContext.fetch(request)
            let firstObject = objects.first
            firstObject?.time = editTime.date
            PersistentController.shared.save()
            SetAlarmViewController.notify(fullAlarm: alarm!)
        }catch {
            
        }
        delegate?.reload()
    }
    
    
}
