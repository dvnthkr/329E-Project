//
//  EditViewController.swift
//  FinalProject
//
//  Created by Devan Thakur on 11/9/21.
//

import Foundation
import UIKit

class EditViewController: UIViewController {
    
    @IBOutlet weak var editTime: UIDatePicker!
    @IBOutlet weak var saveEditedAlarm: UIButton!
    @IBOutlet weak var deleteAlarm: UIButton!
    
    var alarm: Alarm?
    weak var delegate: reloadAlarm?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        deleteAlarm.addTarget(self, action: #selector(didTapDeleteAlarm), for: .touchUpInside)
        saveEditedAlarm.addTarget(self, action: #selector(didTapEditAlarm), for: .touchUpInside)
        
    }
    
    @objc func didTapDeleteAlarm() {
        guard let alarmId = alarm?.id else {
            return
        }
        deleteAlarm(id: alarmId)
        delegate?.reload()
        navigationController?.popToRootViewController(animated: true)
    }
    
    private func deleteAlarm(id: String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let request = Alarm.fetchRequest()
        request.predicate = NSPredicate.init(format: "id==%@", id)
        do {
            let objects = try PersistentController.shared.container.viewContext.fetch(request)
            for object in objects {
                appDelegate.persistentContainer.viewContext.delete(object)
            }
            PersistentController.shared.save()
        }catch {
            
        }
    }
    
    @objc func didTapEditAlarm() {
        guard let alarmId = alarm?.id else {
            return
        }
        editAlarm(id: alarmId)
        delegate?.reload()
        navigationController?.popToRootViewController(animated: true)
    }
    
    private func editAlarm(id: String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let request = Alarm.fetchRequest()
        request.predicate = NSPredicate.init(format: "id==%@", id)
        do {
            let objects = try PersistentController.shared.container.viewContext.fetch(request)
            let firstObject = objects.first
            firstObject?.time = editTime.date
            PersistentController.shared.save()
        }catch {
            
        }
        delegate?.reload()
    }
    
    
}
