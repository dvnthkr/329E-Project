//
//  ViewController.swift
//  FinalProject
//
//  Created by Devan Thakur on 10/27/21.
//

import UIKit
import CoreData

var alarmList: [Alarm] = []



protocol reloadAlarm: AnyObject {
    func reload()
}

let reuseIdentifier = "MyCell"

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, reloadAlarm, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var alarmView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        getData()
        
        
        alarmView.collectionViewLayout = UICollectionViewFlowLayout()
        alarmView.delegate = self
        alarmView.dataSource = self
    }
    
    func getData() {
        let fetchRequest : NSFetchRequest<Alarm> = Alarm.fetchRequest()
        let object = try? PersistentController.shared.container.viewContext.fetch(fetchRequest)
        alarmList.removeAll()
        alarmList.append(contentsOf: object ?? [])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let dest = segue.destination as? SetAlarmViewController {
            dest.delegate = self
        }
        if let dest = segue.destination as? EditViewController, let sender = (sender as? CollectionViewCell)?.indexPath as? IndexPath {
            dest.delegate = self
            dest.alarm = alarmList[sender.row]
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return alarmList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CollectionViewCell
        cell.indexPath = indexPath
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh:mm a"
        let formatedDate = dateFormatter.string(from: alarmList[indexPath.row].time ?? Date())
        cell.myLabel.text = formatedDate
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width, height: 72)
    }
    
    func reload() {
        getData()
        alarmView.reloadData()
    }
    
    
    
   

}

