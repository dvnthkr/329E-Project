//
//  CongratulationsVC.swift
//  Project 329E
//
//  Created by Michael Calizzi on 11/18/21.
//

import UIKit

class CongratulationsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func `return`(_ sender: Any) {
        performSegue(withIdentifier: "back", sender: "")
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
