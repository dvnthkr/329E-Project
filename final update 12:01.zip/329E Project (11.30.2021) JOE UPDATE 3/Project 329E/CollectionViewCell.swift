//
//  CollectionViewCell.swift
//  FinalProject
//
//  Created by Devan Thakur on 11/1/21.
//

import Foundation
import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var alarmOnOff: UISwitch!
    var indexPath: IndexPath?
}
