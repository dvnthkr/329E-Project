//
//  CongratulationsVC.swift
//  Project 329E
//
//  Created by Michael Calizzi on 11/18/21.
//

import UIKit

class CongratulationsVC: UIViewController {
    let fadeIn = CABasicAnimation(keyPath: "opacity")

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        // Do any additional setup after loading the view.
        fadeIn.fromValue = 0
        fadeIn.toValue = 1
        fadeIn.duration = 2
        fadeIn.timingFunction = CAMediaTimingFunction(name: .easeIn)
        
        message.layer.opacity = 0
        button.layer.opacity = 0
    }
    
    override func viewDidAppear(_ animated: Bool) {
        message.layer.add(fadeIn, forKey: nil)
        button.layer.add(fadeIn, forKey: nil)
        
        message.layer.opacity = 1
        button.layer.opacity = 1
    }
    
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var button: UIButton!
    
    
    
    @IBAction func `return`(_ sender: Any) {
        performSegue(withIdentifier: "back", sender: "")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        notifClicked = true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
